using System;
using System.Collections.Generic;
using System.Text;

namespace UcuLifeLib.Listener
{
    public interface IBlockSelectedListener: IListener
    {
        void BlockSelected();
    }
}
