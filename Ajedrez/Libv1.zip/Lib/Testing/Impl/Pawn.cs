﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using Lib;

namespace Testing.Impl
{
    class Pawn : Lib.IPiece
    {
        public enum Direction
        {
            Up = 1,
            Down = -1
        }
        bool firstMove = true;
        Coordenada currentPosition;
        Direction direction;
        IShape shape;
        
        public Pawn(Coordenada initialPos, Direction direction, IShape shape)
        {
            this.direction = direction;
            this.currentPosition = initialPos;
            this.shape = shape;
        }
        public bool IsValidMove(Coordenada newPos, IBoard board)
        {
            List<Coordenada> validMoves = this.ValidMoves(board);
            bool validMove = false;
            foreach (Coordenada c in validMoves)
            {
                if ((c.X == newPos.X) && (c.Y == newPos.Y))
                {
                    validMove = true;
                }
            }
            return validMove;
        }

        public List<Coordenada> ValidMoves(IBoard board)
        {
            List<Coordenada> validMoves = new List<Coordenada>();
            Coordenada newCoordenada;

            //un lugar adelante
            newCoordenada = new Coordenada(this.currentPosition.X, this.currentPosition.Y + 1 * Convert.ToInt32((this.direction)));
            if ((board.Height <= newCoordenada.Y) && (board.Width <= newCoordenada.X) && (!board.GetCell(newCoordenada.X, newCoordenada.Y).HasPiece()))
            {
                validMoves.Add(newCoordenada);
            }
            return validMoves;
        }

        public IShape GetShape()
        {
            return this.shape;
        }

        public Lib.Color GetShapeColor()
        {
            return new Lib.Color(0,0,255);
        }

        public void Move(Coordenada newPos)
        {
 
        }

    }
}
