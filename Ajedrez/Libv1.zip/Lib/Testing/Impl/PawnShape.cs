﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Testing.Impl
{
    class PawnShape : Lib.IShape
    {
        public System.Drawing.Drawing2D.GraphicsPath GetShape()
        {
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddLine(new Point(50, 10), new Point(90, 90));
            path.AddLine(new Point(90, 90), new Point(10, 90));
            path.CloseFigure();
            return path;
        }

        public Lib.Color GetShapeColor()
        {
            return new Lib.Color(0, 0, 255);
        }
    }
}
