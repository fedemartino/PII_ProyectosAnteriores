﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lib;

namespace Testing.Impl
{
    class Cell : ICell
    {
        Color color;
        IPiece piece;

        public IPiece GetPiece()
        {
            return this.piece;
        }

        public Cell(Color color)
        {
            this.color = color;
        }
        public void AddPiece(IPiece piece)
        {
            this.piece = piece;
        }

        public void RemovePiece()
        {
            this.piece = null;
        }

        public Color GetColor()
        {
            return this.color;
        }

        public bool HasPiece()
        {
            return this.piece != null;
        }
    }
}
